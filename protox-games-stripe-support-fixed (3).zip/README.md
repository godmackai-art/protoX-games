<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/6fa233af-72e5-494d-b898-2f6d0ce27aff

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Cloudflare Pages deployment and optional Stripe support

This project uses Cloudflare Pages Functions in the root `functions/` directory.
Deploy it as a **Pages** project (not as a plain static upload):

```bash
npm install
npm run build
npx wrangler pages deploy dist --project-name protox-games
```

In Cloudflare Pages, add `STRIPE_SECRET_KEY` as a server-side secret for the
Production environment (and Preview too only if you intentionally test there).
The key must be a Stripe secret key (`sk_test_...` for testing or `sk_live_...`
for live payments). Never put it in a `VITE_` variable or commit it to Git.

`STRIPE_PRODUCT_ID` is optional. If supplied, it must be a Stripe **Product ID**
starting with `prod_`, not a Price ID starting with `price_`. The checkout
creates one-time payments for the optional $1, $10, and $100 support amounts;
there are no subscriptions and no required payments to play games.

After deployment, check these same-origin endpoints on the production domain:

- `/api/stripe/config` — should return `configured: true`.
- `/api/health` — should return the Pages Function health response.

If a real Stripe secret was ever committed to Git or shared in a ZIP, rotate it
in the Stripe Dashboard before adding the replacement as a Cloudflare secret.
